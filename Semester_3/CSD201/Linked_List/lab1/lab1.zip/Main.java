import java.util.Scanner;

// Lớp Node: đại diện cho 1 phần tử trong danh sách
class Node {
    int data;   // dữ liệu lưu trong node
    Node next;  // tham chiếu tới node kế tiếp

    // Constructor để khởi tạo node mới
    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

// Lớp MyLinkedList: quản lý danh sách liên kết đơn
class MyLinkedList {
    Node head;  // node đầu tiên trong danh sách

    // Constructor: ban đầu danh sách rỗng
    MyLinkedList() {
        head = null;
    }

    // Hàm thêm node vào ĐẦU danh sách
    public void addFirst(int data) {
        Node newNode = new Node(data); // tạo node mới
        newNode.next = head;           // node mới trỏ tới node đầu cũ
        head = newNode;                // cập nhật head = node mới
    }

    // Hàm thêm node vào CUỐI danh sách
    public void addLast(int data) {
        Node newNode = new Node(data); // tạo node mới
        if (head == null) {            // nếu danh sách rỗng
            head = newNode;            // node mới chính là head
            return;
        }
        Node current = head;           // bắt đầu từ node đầu
        while (current.next != null) { // duyệt đến node cuối
            current = current.next;
        }
        current.next = newNode;        // nối node mới vào cuối
    }

    // Hàm in danh sách
    public void printList() {
        Node current = head;           // bắt đầu từ node đầu
        while (current != null) {      // duyệt qua từng node
            System.out.print(current.data + " -> "); 
            current = current.next;    // chuyển sang node kế
        }
        System.out.println("[null]");    // kết thúc danh sách
    }
}

// Lớp Main để chạy thử
public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        MyLinkedList list = new MyLinkedList();

        while (true) {
            System.out.println("\n--- MENU ---");
            System.out.println("1. Add node at the BEGINNING");
            System.out.println("2. Add node at the END");
            System.out.println("3. Print the list");
            System.out.println("0. Exit");
            System.out.print("Choose: ");

            int choice = sc.nextInt();

            if (choice == 0) break;

            switch (choice) {
                 case 1:
                    System.out.print("Enter value: ");
                    int x1 = sc.nextInt();
                    list.addFirst(x1);
                    break;
                case 2:
                    System.out.print("Enter value: ");
                    int x2 = sc.nextInt();
                    list.addLast(x2);
                    break;
                case 3:
                    list.printList();
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
        sc.close();
    }
}

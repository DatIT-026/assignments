SELECT
	c.CustomerID,
	c.FullName,
	r.ReservationTime,
	rt.TableID,
	t.Location
FROM Customers c
JOIN Reservations r ON c.CustomerID = r.CustomerID
JOIN ReservationTables rt ON r.ReservationID = rt.ReservationID
JOIN Tables t ON rt.TableID  = t.TableID
WHERE YEAR(r.ReservationTime) = 2025 AND t.Location LIKE '%Khu A%' 
SELECT 
	e.EmployeeID,
	e.FullName,
	e.Role,
	e.HireDate,
	e.Salary
FROM Employees e
WHERE YEAR(e.HireDate) = 2021
public class Node {
    int info;
    Node left, right;

    public Node(int info) {
        this.info = info;
        left = right = null;
    }
}
// =========== DO NOT EDIT THE GIVEN CONTENT OF THIS FILE ============
class Canary {
  String place;
  int song,wing;
  Canary() {
   }
  Canary(String xPlace, int xSong, int xWing){
    place=xPlace;song=xSong; wing=xWing;
   }
  public String toString(){
    return("(" +place+","+song + "," + wing + ")");
   }
 }

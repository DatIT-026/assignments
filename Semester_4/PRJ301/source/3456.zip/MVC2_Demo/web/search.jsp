<%-- 
    Document   : search
    Created on : Dec 12, 2025, 10:39:21 PM
    Author     : Admin
--%>

<%@page import="cuongnh.registration.RegistrationDTO"%>
<%@page import="java.util.List"%>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<%@taglib uri="http://java.sun.com/jsp/jstl/core" prefix="c"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Search Page</title>
    </head>
    <body>

        <h1 style="color: red">Search Page</h1>
        <form action="DispatchServlet" >
            Search <input type="text" name="txtSearchValue" 
                          value="${param.txtSearchValue}" /><br/>
            <input type="submit" value="Search" name="btAction" />
        </form><br/>

        <c:set var="searchValue" value="${param.txtSearchValue}"/>
        <c:if test="${not empty searchValue}">
            <c:set var="result" value="${requestScope.SEARCH_RESULT}"/>
            <c:if test="${not empty result}">
                <table border="1">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>Username</th>
                            <th>Password</th>
                            <th>Full Name</th>
                            <th>Role</th>
                        </tr>
                    </thead>
                    <tbody>
                        <c:forEach var="dto" items="${result}" varStatus="counter">
                            <tr>
                                <td>
                                    ${counter.count}
                                </td>
                                <td>
                                    ${dto.username}
                                </td>
                                <td>
                                    ${dto.password}
                                </td>
                                <td>
                                    ${dto.fullName}
                                </td>
                                <td>
                                    ${dto.role}
                                </td>
                            </tr>
                        </c:forEach>
                    </tbody>
                </table>

            </c:if>
            <c:if test="${empty result}">
                <h2>
                    <font color="red">
                    No Record is matched!!!
                    </font>
                </h2>
            </c:if>
        </c:if>

        <%--
        <h1 style="color: red">Search Page</h1>
        <form action="DispatchServlet" >
            Search <input type="text" name="txtSearchValue" 
                          value="<%= request.getParameter("txtSearchValue") %>" /><br/>
            <input type="submit" value="Search" name="btAction" />
        </form><br/>
        
        <% 
            String searchValue = request.getParameter("txtSearchValue");
            if (searchValue != null) {
                List<RegistrationDTO> result = 
                    (List<RegistrationDTO>) request.getAttribute("SEARCH_RESULT");
                
                if (result != null) {
                    %>
                    <table border="1">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Username</th>
                                <th>Password</th>
                                <th>Full Name</th>
                                <th>Role</th>
                            </tr>
                        </thead>
                        <tbody>
                            <% 
                                int count = 0;
                                for (RegistrationDTO dto : result) {
                                    %>
                                    <tr>
                                        <td>
                                            <%= count++ %>
                                        </td>
                                        <td>
                                            <%= dto.getUsername() %>
                                        </td>
                                        <td>
                                            <%= dto.getPassword() %>
                                        </td>
                                        <td>
                                            <%= dto.getFullName() %>
                                        </td>
                                        <td>
                                            <%= dto.isRole() %>
                                        </td>
                                    </tr>
                            <%
                                }
                            %>
                            
                        </tbody>
                    </table>

                           
        <%
                } else {
                    %>
                    <h2>
                        <font color="red">
                            No Record is matched!!!
                        </font>
                    </h2>
        <%
                }
                
            }
        %> --%>
    </body>
</html>

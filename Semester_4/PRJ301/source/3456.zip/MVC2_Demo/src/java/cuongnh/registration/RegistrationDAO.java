/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cuongnh.registration;

import cuongnh.util.DBUtils;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Admin
 */
public class RegistrationDAO implements Serializable {

    public boolean checkLogin(String username, String password)
            throws SQLException, ClassNotFoundException {
        boolean result = false;
        //bao va gan null
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;

        try {
            //1. Connect db
            con = DBUtils.getConnection();

            //2.Model queries data from db
            //2.1. Create sql string
            String sql = "Select username "
                    + "From Registration "
                    + "Where username = ? "
                    + "And password = ?";

            //2.2. Load sql into stm object
            pstm = con.prepareStatement(sql);
            pstm.setString(1, username);
            pstm.setString(2, password);

            //2.3. Execute queries
            rs = pstm.executeQuery();

            if (rs.next()) {
                //3.Model loads data from db to model
                //4.Model process and return result
                result = true;
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstm != null) {
                pstm.close();
            }
            if (con != null) {
                con.close();
            }
        }

        return result;
    }

    //SOLID
    List<RegistrationDTO> accounts;

    public List<RegistrationDTO> getAccounts() {
        return accounts;
    }

    public void searchLastName(String searchValue)
            throws SQLException, ClassNotFoundException {
        //bao va gan null
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;

        try {
            //1. Connect db
            con = DBUtils.getConnection();
            if (con != null) {

                //2.Model queries data from db
                //2.1. Create sql string
                String sql = "Select username, password, lastname, isAdmin "
                        + "From Registration "
                        + "Where lastname Like ?";

                //2.2. Load sql into stm object
                pstm = con.prepareStatement(sql);
                pstm.setString(1, "%" + searchValue + "%");
                
                //2.3. Execute queries
                rs = pstm.executeQuery();
                
                while(rs.next()) {
                    //2.3.1 Model load data from db
                    String username = rs.getString("username");
                    String password = rs.getString("password");
                    String fullname = rs.getString("lastname");
                    boolean role = rs.getBoolean("isAdmin");
                    RegistrationDTO dto = new RegistrationDTO(username, password, fullname, role);
                    //2.3.2 Model store data from db to itself
                    if (this.accounts == null) {
                        accounts = new ArrayList<>();
                    }
                    this.accounts.add(dto);
                }
            }

        } finally {
            if (rs != null) {
                rs.close();
            }
            if (pstm != null) {
                pstm.close();
            }
            if (con != null) {
                con.close();
            }
        }
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package cuongnh.controller;

import cuongnh.registration.RegistrationCreateError;
import cuongnh.registration.RegistrationDAO;
import cuongnh.registration.RegistrationDTO;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author C00kies
 */
@WebServlet(name = "CreateAccountServlet", urlPatterns = {"/CreateAccountServlet"})
public class CreateAccountServlet extends HttpServlet {

    private static final String LOGIN_PAGE = "login.jsp";
    private static final String ERROR_PAGE = "createAccount.jsp";

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String url = ERROR_PAGE;

        String username = request.getParameter("txtUsername");
        String password = request.getParameter("txtPassword");
        String lastName = request.getParameter("txtLastName");
        String confirm = request.getParameter("txtConfirm");

        boolean foundError = false;
        RegistrationCreateError errors = new RegistrationCreateError();

        try {

            if (username.trim().length() < 2 || username.trim().length() > 20) {
                foundError = true;
                errors.setUsernameLengthError("Username from 2 - 20 characters");
            } 
            if (password.trim().length() < 2 || password.trim().length() > 30) {
                foundError = true;
                errors.setPasswordLengthError("Password from 2 - 30 characters");
            } else if (!confirm.trim().equals(password.trim())){
                foundError = true;
                errors.setConfirmNotMatch("Confirm must match password");
            }
            if (lastName.trim().length() < 2 || lastName.trim().length() > 50) {
                foundError = true;
                errors.setLastnameLengthError("Username from 2 - 50 characters");
            }
            
            if (foundError){
                request.setAttribute("CREATE_ERRORS", errors);
            } else {
                RegistrationDAO dao = new RegistrationDAO();
                RegistrationDTO dto = new RegistrationDTO(username, password, lastName, false);
                boolean result = dao.createAccount(dto);

                if (result) {
                    url = LOGIN_PAGE;
                }
            }


        } catch (ClassNotFoundException ex) {
            log ("CreateAccountServlet_SQL: " + ex.getMessage());
        } catch (SQLException ex) {
            String errMsg = ex.getMessage();
            if (errMsg.contains("duplicate")) {
                errors.setUsernameIsExisted(username + " is EXISTED");
                request.setAttribute("CREATE_ERRORS", errors);
            }
            ex.printStackTrace();
        } finally {
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

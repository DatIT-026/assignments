<%-- 
    Document   : createAccount
    Created on : Jan 7, 2026, 10:47:59 PM
    Author     : C00kies
--%>

<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>JSP Page</title>
    </head>
    <body>
        <h2 style="color: red">Create Account</h2>
        <form action="createAccount" method="POST">
            <c:set var="errors" value="${requestScope.CREATE_ERRORS}" />
            
            Username* <input type="text" name="txtUsername" value="${param.txtUsername}" required="" /> (2-20 characters) <br/>
            <c:if test="${not empty errors.usernameLengthError}">
                  <font color="red">${errors.usernameLengthError}</font> <br/>
            </c:if>
            <c:if test="${not empty errors.usernameIsExisted}">
                  <font color="red">${errors.usernameIsExisted}</font> <br/>
            </c:if>
            
            Password* <input type="password" name="txtPassword" value="" required="" /> (2-30 characters) <br/>
            <c:if test="${not empty errors.passwordLengthError}">
                  <font color="red">${errors.passwordLengthError}</font> <br/>
            </c:if>
    
            Confirm* <input type="password" name="txtConfirm" value="" required="" /> <br/>
            <c:if test="${not empty errors.confirmNotMatch}">
                  <font color="red">${errors.confirmNotMatch}</font> <br/>
            </c:if>

            Last Name* <input type="text" name="txtLastName" value="${param.txtLastName}" required="" /> (2-50 characters)<br/>
            <c:if test="${not empty errors.lastnameLengthError}">
                  <font color="red">${errors.lastnameLengthError}</font> <br/>
            </c:if>

            <input type="submit" value="Create" name="btAction" />
        </form>
        <br/>
        <a href="login.jsp">Click here to go back</a>
    </body>
</html>
